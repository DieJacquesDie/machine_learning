###
Afin d'utiliser ce script, les fichiers doivent etre tries par classe au sein de repertoires differents. Ces repertoires doivent etre dans un dossier nomme 'data'.
###


import os
import numpy as np

from python_speech_features import mfcc
import scipy.io.wavfile as wav


X = []
Y = []
c = 0
for directory in os.listdir('data'):
    for filename in os.listdir('data\\'+directory):
        
        (rate,sig) = wav.read('data\\'+directory+'\\'+filename)
        x = mfcc(sig,rate,nfft=1250)
        
        for i in range(len(x)):
            X.append(x[i])
            Y.append(c)
    
    c += 1
        
X = np.asarray(X)
Y = np.asarray(Y)

np.save('X.npy', X)
np.save('Y.npy', Y)

